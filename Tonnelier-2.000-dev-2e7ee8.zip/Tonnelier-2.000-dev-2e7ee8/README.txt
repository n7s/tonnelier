This is the Tonnelier fork of Cooper Hewitt.
Tonnelier is french for Cooper. 

Chester Jenkins of [Village](http://vllg.com/) created the custom typeface called Cooper Hewitt for the [Cooper Hewitt](http://www.cooperhewitt.org/) Smithsonian Design Museum.
(http://www.cooperhewitt.org/colophon/cooper-hewitt-the-typeface-by-chester-jenkins/).  
This design started life as Galaxie Polaris Condensed, a geometric, sans-serif font that Chester Jenkins had worked on years ago.
(https://vllg.com/constellation/galaxie-polaris-cond).

This Font Software is licensed under SIL Open Font License 1.1 (http://scripts.sil.org/OFL)  
See the FAQ on (http://scripts.sil.org/OFL-FAQ_web).

Foo is released under the SIL Open Font License.
See the OFL and OFL-FAQ for details of the SIL Open Font License.
See the FONTLOG for information on this and previous releases.

For further information about this font, including Unicode ranges
supported, Graphite and OpenType font features and how to use them, 
and licensing, please see the documentation on the website
or in the documentation/ subfolder.
